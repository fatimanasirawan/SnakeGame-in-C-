USE SnakeGameDB;
    
SELECT * FROM Players;

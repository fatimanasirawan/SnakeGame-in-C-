﻿namespace Snake
{
    public enum GridValue
    {
        Empty,
        Snake,
        Food,
        Outside
    }
}
